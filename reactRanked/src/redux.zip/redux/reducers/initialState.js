export default {
    currentCategory: {categoryName:"Beverages"}, //todo change this name
    categories: [],
    products: [],
    cart: [],
    users:[],
    totalPrice: 0,
    currentUser:{
            id: 0,
            name: "",
            password: "",
            email: "",
            role: ""
        },
    orders: [
    ],

        
    
};